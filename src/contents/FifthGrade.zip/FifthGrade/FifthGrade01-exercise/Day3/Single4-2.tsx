import Styled from '../../style';

const Single42 = () => {
  return (
    <Styled.RowBox2>
      <div></div>
      <Styled.SingleWrapper3>
        <Styled.InputWrapper2>
          <div>7</div>
          <div>x</div>
          <div>3</div>
          <div>x</div>
          <div>4</div>
          <div>
            <Styled.InputWrapper>
              <div>=</div>
              <Styled.InputBox1></Styled.InputBox1>
              <div>1</div>
              <Styled.InputBox1></Styled.InputBox1>
              <div>2</div>
            </Styled.InputWrapper>
            <div>
              <Styled.InputWrapper>
                <div>=</div>
                <Styled.InputBox1></Styled.InputBox1>
                <div>3 =</div>
                <Styled.InputBox1></Styled.InputBox1>
              </Styled.InputWrapper>
            </div>
          </div>
        </Styled.InputWrapper2>
      </Styled.SingleWrapper3>
    </Styled.RowBox2>
  );
};

export default Single42;

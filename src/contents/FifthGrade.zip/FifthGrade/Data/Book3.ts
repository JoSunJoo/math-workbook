//데이터미적용
export const Data13Quiz = [
  { id: '①', quiz1: 20, quiz2: 4 },
  { id: '②', quiz1: 30, quiz2: 8 },
  { id: '③', quiz1: 40, quiz2: 3 },
  { id: '④', quiz1: 90, quiz2: 3 },
  { id: '⑤', quiz1: 10, quiz2: 4 },
  { id: '⑥', quiz1: 60, quiz2: 8 },
  { id: '⑦', quiz1: 30, quiz2: 2 },
  { id: '⑧', quiz1: 20, quiz2: 9 },
  { id: '⑨', quiz1: 50, quiz2: 7 },
  { id: '⑩', quiz1: 40, quiz2: 3 },
  { id: '⑪', quiz1: 20, quiz2: 2 },
  { id: '⑫', quiz1: 60, quiz2: 4 },
  { id: '⑬', quiz1: 30, quiz2: 5 },
  { id: '⑭', quiz1: 70, quiz2: 4 },
];

export const Data23Quiz = [
  { id: '①', quiz1: 40, quiz2: 30 },
  { id: '②', quiz1: 70, quiz2: 20 },
  { id: '③', quiz1: 80, quiz2: 50 },
  { id: '④', quiz1: 80, quiz2: 80 },
  { id: '⑤', quiz1: 30, quiz2: 60 },
  { id: '⑥', quiz1: 20, quiz2: 40 },
  { id: '⑦', quiz1: 50, quiz2: 70 },
  { id: '⑧', quiz1: 60, quiz2: 80 },
  { id: '⑨', quiz1: 50, quiz2: 50 },
  { id: '⑩', quiz1: 40, quiz2: 90 },
  { id: '⑪', quiz1: 60, quiz2: 20 },
  { id: '⑫', quiz1: 80, quiz2: 30 },
];

//데이터 미적용
export const Data33Quiz = [
  { id: '①', quiz1: 20, quiz2: 4 },
  { id: '②', quiz1: 30, quiz2: 8 },
  { id: '③', quiz1: 40, quiz2: 3 },
  { id: '④', quiz1: 90, quiz2: 3 },
  { id: '⑤', quiz1: 10, quiz2: 4 },
  { id: '⑥', quiz1: 60, quiz2: 8 },
  { id: '⑦', quiz1: 30, quiz2: 2 },
  { id: '⑧', quiz1: 20, quiz2: 9 },
  { id: '⑨', quiz1: 50, quiz2: 7 },
  { id: '⑩', quiz1: 40, quiz2: 3 },
  { id: '⑪', quiz1: 20, quiz2: 2 },
  { id: '⑫', quiz1: 60, quiz2: 4 },
  { id: '⑬', quiz1: 30, quiz2: 5 },
  { id: '⑭', quiz1: 70, quiz2: 4 },
];

//데이터 미적용
export const Data43Quiz = [
  { id: '①', quiz1: 40, quiz2: 30 },
  { id: '②', quiz1: 70, quiz2: 20 },
  { id: '③', quiz1: 80, quiz2: 50 },
  { id: '④', quiz1: 80, quiz2: 80 },
  { id: '⑤', quiz1: 30, quiz2: 60 },
  { id: '⑥', quiz1: 20, quiz2: 40 },
  { id: '⑦', quiz1: 50, quiz2: 70 },
  { id: '⑧', quiz1: 60, quiz2: 80 },
  { id: '⑨', quiz1: 50, quiz2: 50 },
  { id: '⑩', quiz1: 40, quiz2: 90 },
  { id: '⑪', quiz1: 60, quiz2: 20 },
  { id: '⑫', quiz1: 80, quiz2: 30 },
];

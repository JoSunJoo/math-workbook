import styled from '@emotion/styled';

const Styled = {

    };


export default Styled;
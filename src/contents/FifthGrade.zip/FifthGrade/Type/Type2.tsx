export interface Data12QuizProps {
  id: string;
  quiz1: string;
  quiz2: string;
}

export interface Data22QuizProps {
  id: string;
  quiz1: string;
  quiz2: string;
  quiz3: string;
}
